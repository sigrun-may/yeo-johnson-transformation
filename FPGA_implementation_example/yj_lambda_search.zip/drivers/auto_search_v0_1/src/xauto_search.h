// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2023 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XAUTO_SEARCH_H
#define XAUTO_SEARCH_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xauto_search_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Ctrl_bus_BaseAddress;
} XAuto_search_Config;
#endif

typedef struct {
    u64 Ctrl_bus_BaseAddress;
    u32 IsReady;
} XAuto_search;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XAuto_search_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XAuto_search_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XAuto_search_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XAuto_search_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XAuto_search_Initialize(XAuto_search *InstancePtr, u16 DeviceId);
XAuto_search_Config* XAuto_search_LookupConfig(u16 DeviceId);
int XAuto_search_CfgInitialize(XAuto_search *InstancePtr, XAuto_search_Config *ConfigPtr);
#else
int XAuto_search_Initialize(XAuto_search *InstancePtr, const char* InstanceName);
int XAuto_search_Release(XAuto_search *InstancePtr);
#endif

void XAuto_search_Start(XAuto_search *InstancePtr);
u32 XAuto_search_IsDone(XAuto_search *InstancePtr);
u32 XAuto_search_IsIdle(XAuto_search *InstancePtr);
u32 XAuto_search_IsReady(XAuto_search *InstancePtr);
void XAuto_search_EnableAutoRestart(XAuto_search *InstancePtr);
void XAuto_search_DisableAutoRestart(XAuto_search *InstancePtr);

void XAuto_search_Set_rows(XAuto_search *InstancePtr, u32 Data);
u32 XAuto_search_Get_rows(XAuto_search *InstancePtr);
void XAuto_search_Set_size_of_stream(XAuto_search *InstancePtr, u32 Data);
u32 XAuto_search_Get_size_of_stream(XAuto_search *InstancePtr);
void XAuto_search_Set_precision(XAuto_search *InstancePtr, u32 Data);
u32 XAuto_search_Get_precision(XAuto_search *InstancePtr);

void XAuto_search_InterruptGlobalEnable(XAuto_search *InstancePtr);
void XAuto_search_InterruptGlobalDisable(XAuto_search *InstancePtr);
void XAuto_search_InterruptEnable(XAuto_search *InstancePtr, u32 Mask);
void XAuto_search_InterruptDisable(XAuto_search *InstancePtr, u32 Mask);
void XAuto_search_InterruptClear(XAuto_search *InstancePtr, u32 Mask);
u32 XAuto_search_InterruptGetEnabled(XAuto_search *InstancePtr);
u32 XAuto_search_InterruptGetStatus(XAuto_search *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
